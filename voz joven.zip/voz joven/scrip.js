// Aquí puedes agregar futuras funciones, como notificaciones, visualizador, etc.
console.log("Reproductor cargado.");
